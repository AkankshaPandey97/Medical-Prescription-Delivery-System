USE PharmacyDBDemo5;
GO

-- Import data into Address table
BULK INSERT Address
FROM '.\address.csv'
WITH (
    FIELDTERMINATOR = ',',  -- CSV field delimiter
    ROWTERMINATOR = '\n',   -- CSV row delimiter
    FIRSTROW = 2            -- If the first row is column headers
);
GO
Select * from Address


-- Import data into Patient table
BULK INSERT Patient
FROM 'C:\Users\anjal\Downloads\DMDD Project Data\patient.csv'
WITH (
    FIELDTERMINATOR = ',',
    ROWTERMINATOR = '\n',
    FIRSTROW = 2
);
GO

-- Repeat the BULK INSERT command for each table with the corresponding CSV file

-- Import data into Physician table
BULK INSERT Physician
FROM 'C:\Users\anjal\Downloads\DMDD Project Data\physician.csv'
WITH (
    FIELDTERMINATOR = ',',
    ROWTERMINATOR = '\n',
    FIRSTROW = 2
);
GO

-- Import data into Prescription table
BULK INSERT Prescription
FROM 'C:\Users\anjal\Downloads\DMDD Project Data\prescription.csv'
WITH (
    FIELDTERMINATOR = ',',
    ROWTERMINATOR = '\n',
    FIRSTROW = 2
);
GO

-- Import data into MedicationItem table
BULK INSERT MedicationItem
FROM 'C:\Users\anjal\Downloads\DMDD Project Data\medication_item.csv'
WITH (
    FIELDTERMINATOR = ',',
    ROWTERMINATOR = '\n',
    FIRSTROW = 2
);
GO

-- Import data into Pharmacy table
BULK INSERT Pharmacy
FROM 'C:\Users\anjal\Downloads\DMDD Project Data\pharmacy.csv'
WITH (
    FIELDTERMINATOR = ',',
    ROWTERMINATOR = '\n',
    FIRSTROW = 2
);
GO
select* from pharmacy

-- Import data into Inventory table
BULK INSERT Inventory
FROM 'C:\Users\anjal\Downloads\DMDD Project Data\inventory.csv'
WITH (
    FIELDTERMINATOR = ',',
    ROWTERMINATOR = '\n',
    FIRSTROW = 2
);
GO

-- Import data into Order table
BULK INSERT [Order]
FROM 'C:\Users\anjal\Downloads\DMDD Project Data\order.csv'
WITH (
    FIELDTERMINATOR = ',',
    ROWTERMINATOR = '\n',
    FIRSTROW = 2
);
GO

-- Import data into OrderItem table
BULK INSERT OrderItem
FROM 'C:\Users\anjal\Downloads\DMDD Project Data\order_item.csv'
WITH (
    FIELDTERMINATOR = ',',
    ROWTERMINATOR = '\n',
    FIRSTROW = 2
);
GO

-- Import data into DeliveryPerson table
BULK INSERT DeliveryPerson
FROM 'C:\Users\anjal\Downloads\DMDD Project Data\delivery_person.csv'
WITH (
    FIELDTERMINATOR = ',',
    ROWTERMINATOR = '\n',
    FIRSTROW = 2
);
GO

-- Import data into Delivery table
BULK INSERT Delivery
FROM 'C:\Users\anjal\Downloads\DMDD Project Data\delivery.csv'
WITH (
    FIELDTERMINATOR = ',',
    ROWTERMINATOR = '\n',
    FIRSTROW = 2
);
GO

-- Import data into Supplier table
BULK INSERT Supplier
FROM 'C:\Users\anjal\Downloads\DMDD Project Data\supplier.csv'
WITH (
    FIELDTERMINATOR = ',',
    ROWTERMINATOR = '\n',
    FIRSTROW = 2
);
GO

-- Import data into SupplyRecord table
BULK INSERT SupplyRecord
FROM 'C:\Users\anjal\Downloads\DMDD Project Data\supply_record.csv'
WITH (
    FIELDTERMINATOR = ',',
    ROWTERMINATOR = '\n',
    FIRSTROW = 2
);
GO

-- Import data into Transactions table
BULK INSERT Transactions
FROM 'C:\Users\anjal\Downloads\DMDD Project Data\transaction.csv'
WITH (
    FIELDTERMINATOR = ',',
    ROWTERMINATOR = '\n',
    FIRSTROW = 2
);
GO